if( GetLocale() == "ruRU" ) then
	MBB_TOOLTIP1 = "Ctrl + ПКМ на кнопку, чтобы прикрепить/открепить ее от миникарты.\nShift + Left Drag чтобы перемещать кнопку аддона.";
	MBB_OPTIONS_HEADER = "Настройки";
	MBB_OPTIONS_OKBUTTON = "Ок";
	MBB_OPTIONS_CANCELBUTTON = "Отмена";
	MBB_OPTIONS_SLIDEROFF = "Выкл.";
	MBB_OPTIONS_SLIDERSEK = "сек.";
	MBB_OPTIONS_SLIDERLABEL = "Таймаут до скрытия:";
	MBB_OPTIONS_EXPANSIONLABEL = "Расширяться:";
	MBB_OPTIONS_EXPANSIONLEFT = "Влево";
	MBB_OPTIONS_EXPANSIONTOP = "Вверх";
	MBB_OPTIONS_EXPANSIONRIGHT = "Вправо";
	MBB_OPTIONS_EXPANSIONBOTTOM = "Вниз";
	MBB_OPTIONS_MAXBUTTONSLABEL = "Max. кнопок в строке:";
	MBB_OPTIONS_MAXBUTTONSINFO = "(0=бесконечно)";
	MBB_OPTIONS_ALTEXPANSIONLABEL = "Расширять строки:";
	MBB_OPTIONS_SCALE="Масштаб кнопок";
	MBB_HELP1 = "Введите \"/mbb <cmd>\", где <cmd> одна из команд:";
	MBB_HELP2 = "  |c00ffffffbuttons|r: Показать список всех кнопок в MBB";
	MBB_HELP3 = "  |c00ffffffreset position|r: Сбросить позицию кнопки МBB у миникарты";
	MBB_HELP4 = "  |c00ffffffreset all|r: Сбросить все настройки";
	MBB_NOERRORS = "Ошибок не найдено!";
end
