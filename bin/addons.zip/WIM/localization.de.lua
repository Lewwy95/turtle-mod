if (GetLocale() == "deDE") then
	-- Class Names
	WIM_LOCALIZED_DRUID = "Druide";
	WIM_LOCALIZED_HUNTER = "J\195\164ger";
	WIM_LOCALIZED_MAGE = "Magier";
	WIM_LOCALIZED_PALADIN = "Paladin";
	WIM_LOCALIZED_PRIEST = "Priester";
	WIM_LOCALIZED_ROGUE = "Schurke";
	WIM_LOCALIZED_SHAMAN = "Schamane";
	WIM_LOCALIZED_WARLOCK = "Hexenmeister";
	WIM_LOCALIZED_WARRIOR = "Krieger";
end