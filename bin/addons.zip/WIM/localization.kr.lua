if (GetLocale() == "koKR") then
	-- Class Names
	WIM_LOCALIZED_DRUID = "드루이드";
	WIM_LOCALIZED_HUNTER = "사냥꾼";
	WIM_LOCALIZED_MAGE = "마법사";
	WIM_LOCALIZED_PALADIN = "성기사";
	WIM_LOCALIZED_PRIEST = "사제";
	WIM_LOCALIZED_ROGUE = "도적";
	WIM_LOCALIZED_SHAMAN = "주술사";
	WIM_LOCALIZED_WARLOCK = "흑마법사";
	WIM_LOCALIZED_WARRIOR = "전사";

end