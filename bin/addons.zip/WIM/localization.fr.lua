if (GetLocale() == "frFR") then
	-- Class Names
	WIM_LOCALIZED_DRUID = "Druide";
	WIM_LOCALIZED_HUNTER = "Chasseur";
	WIM_LOCALIZED_MAGE = "Mage";
	WIM_LOCALIZED_PALADIN = "Paladin";
	WIM_LOCALIZED_PRIEST = "Pr\195\170tre";
	WIM_LOCALIZED_ROGUE = "Voleur";
	WIM_LOCALIZED_SHAMAN = "Chaman";
	WIM_LOCALIZED_WARLOCK = "D\195\169moniste";
	WIM_LOCALIZED_WARRIOR = "Guerrier";
end