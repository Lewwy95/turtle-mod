if (GetLocale() == "zhCN") then
	-- Class Names
	WIM_LOCALIZED_DRUID = "德鲁伊";
	WIM_LOCALIZED_HUNTER = "猎人";
	WIM_LOCALIZED_MAGE = "法师";
	WIM_LOCALIZED_PALADIN = "圣骑士";
	WIM_LOCALIZED_PRIEST = "牧师";
	WIM_LOCALIZED_ROGUE = "盗贼";
	WIM_LOCALIZED_SHAMAN = "萨满祭司";
	WIM_LOCALIZED_WARLOCK = "术士";
	WIM_LOCALIZED_WARRIOR = "战士";
end